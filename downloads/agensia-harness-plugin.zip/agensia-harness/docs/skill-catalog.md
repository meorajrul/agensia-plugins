# Skill catalog

| Skill | Intended departments |
|---|---|
| [agensia-harness](../skills/agensia-harness/SKILL.md) | Engineering, PMO, Operations |
